/*
 *
 * Rooms component
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { Minus, Plus } from 'tabler-icons-react';
import './styles.less';

const AddList = ({ data, onPlusClick, onMinusClick }) => (
  <div className="add-list">
    {data.map(({ name, quantity, _id }) => (
      <div className="add-list__item" key={_id}>
        <div className="add-list__item__name">{name}</div>
        <div className="add-list__item__counter">
          <Minus color="#B5B5B7" onClick={() => onMinusClick(_id, quantity)} />
          <span className="add-list__item__counter__number">{quantity}</span>
          <Plus color="#B5B5B7" onClick={() => onPlusClick(_id, quantity)} />
        </div>
      </div>
    ))}
  </div>
);

AddList.propTypes = {
  data: PropTypes.shape({
    name: PropTypes.string.isRequired,
    quantity: PropTypes.number.isRequired,
  }).isRequired,
  onPlusClick: PropTypes.func.isRequired,
  onMinusClick: PropTypes.func.isRequired,
};

export { AddList };
